# lawn_tractor
Metapackage for self driving lawn tractor.
