# lawn_tractor_sim
![alt text](https://github.com/ros-agriculture/ros-agriculture.github.io/blob/master/media/tractor_sim.png?raw=true "ROS Lawn Tractor")
Original tractor simulator from Olin Robitics Lab:
https://github.com/olinrobotics/tractor_sim
